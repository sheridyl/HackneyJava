/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackneyproject.entities;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Dylan
 */
@Entity
@Table(name = "RECORDS")
@NamedQueries({
    @NamedQuery(name = "Records.findAll", query = "SELECT r FROM Records r"),
    @NamedQuery(name = "Records.findById", query = "SELECT r FROM Records r WHERE r.id = :id"),
    @NamedQuery(name = "Records.findByFromlocation", query = "SELECT r FROM Records r WHERE r.fromlocation = :fromlocation"),
    @NamedQuery(name = "Records.findByTolocation", query = "SELECT r FROM Records r WHERE r.tolocation = :tolocation"),
    @NamedQuery(name = "Records.findByDrivername", query = "SELECT r FROM Records r WHERE r.drivername = :drivername"),
    @NamedQuery(name = "Records.findByOrdertime", query = "SELECT r FROM Records r WHERE r.ordertime = :ordertime"),
    @NamedQuery(name = "Records.findByTime1", query = "SELECT r FROM Records r WHERE r.time1 = :time1"),
    @NamedQuery(name = "Records.findByPrice", query = "SELECT r FROM Records r WHERE r.price = :price"),
    @NamedQuery(name = "Records.findByCustomer", query = "SELECT r FROM Records r WHERE r.customer = :customer")})
public class Records implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "FROMLOCATION")
    private String fromlocation;
    @Column(name = "TOLOCATION")
    private String tolocation;
    @Column(name = "DRIVERNAME")
    private String drivername;
    @Column(name = "ORDERTIME")
    private String ordertime;
    @Column(name = "TIME1")
    private String time1;
    @Column(name = "PRICE")
    private String price;
    @Column(name = "CUSTOMER")
    private String customer;

    public Records() {
    }

    public Records(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getFromlocation() {
        return fromlocation;
    }

    public void setFromlocation(String fromlocation) {
        String oldFromlocation = this.fromlocation;
        this.fromlocation = fromlocation;
        changeSupport.firePropertyChange("fromlocation", oldFromlocation, fromlocation);
    }

    public String getTolocation() {
        return tolocation;
    }

    public void setTolocation(String tolocation) {
        String oldTolocation = this.tolocation;
        this.tolocation = tolocation;
        changeSupport.firePropertyChange("tolocation", oldTolocation, tolocation);
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        String oldDrivername = this.drivername;
        this.drivername = drivername;
        changeSupport.firePropertyChange("drivername", oldDrivername, drivername);
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        String oldOrdertime = this.ordertime;
        this.ordertime = ordertime;
        changeSupport.firePropertyChange("ordertime", oldOrdertime, ordertime);
    }

    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        String oldTime1 = this.time1;
        this.time1 = time1;
        changeSupport.firePropertyChange("time1", oldTime1, time1);
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        String oldPrice = this.price;
        this.price = price;
        changeSupport.firePropertyChange("price", oldPrice, price);
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        String oldCustomer = this.customer;
        this.customer = customer;
        changeSupport.firePropertyChange("customer", oldCustomer, customer);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Records)) {
            return false;
        }
        Records other = (Records) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hackneyproject.entities.Records[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
