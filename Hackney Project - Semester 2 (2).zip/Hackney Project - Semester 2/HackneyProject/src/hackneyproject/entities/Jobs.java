/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackneyproject.entities;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Dylan Sheridan
 */
@Entity
@Table(name = "JOBS")
@NamedQueries({
    @NamedQuery(name = "Jobs.findAll", query = "SELECT j FROM Jobs j"),
    @NamedQuery(name = "Jobs.findById", query = "SELECT j FROM Jobs j WHERE j.id = :id"),
    @NamedQuery(name = "Jobs.findByFromlocation", query = "SELECT j FROM Jobs j WHERE j.fromlocation = :fromlocation"),
    @NamedQuery(name = "Jobs.findByTolocation", query = "SELECT j FROM Jobs j WHERE j.tolocation = :tolocation"),
    @NamedQuery(name = "Jobs.findByDrivername", query = "SELECT j FROM Jobs j WHERE j.drivername = :drivername"),
    @NamedQuery(name = "Jobs.findByCustomer", query = "SELECT j FROM Jobs j WHERE j.customer = :customer"),
    @NamedQuery(name = "Jobs.findByOrdertime", query = "SELECT j FROM Jobs j WHERE j.ordertime = :ordertime"),
    @NamedQuery(name = "Jobs.findByTime", query = "SELECT j FROM Jobs j WHERE j.time = :time"),
    @NamedQuery(name = "Jobs.findByPrice", query = "SELECT j FROM Jobs j WHERE j.price = :price")})
public class Jobs implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "FROMLOCATION")
    private String fromlocation;
    @Column(name = "TOLOCATION")
    private String tolocation;
    @Column(name = "DRIVERNAME")
    private String drivername;
    @Column(name = "CUSTOMER")
    private String customer;
    @Column(name = "ORDERTIME")
    private String ordertime;
    @Column(name = "TIME")
    private String time;
    @Column(name = "PRICE")
    private String price;

    public Jobs() {
    }

    public Jobs(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getFromlocation() {
        return fromlocation;
    }

    public void setFromlocation(String fromlocation) {
        String oldFromlocation = this.fromlocation;
        this.fromlocation = fromlocation;
        changeSupport.firePropertyChange("fromlocation", oldFromlocation, fromlocation);
    }

    public String getTolocation() {
        return tolocation;
    }

    public void setTolocation(String tolocation) {
        String oldTolocation = this.tolocation;
        this.tolocation = tolocation;
        changeSupport.firePropertyChange("tolocation", oldTolocation, tolocation);
    }

    public String getDrivername() {
        return drivername;
    }

    public void setDrivername(String drivername) {
        String oldDrivername = this.drivername;
        this.drivername = drivername;
        changeSupport.firePropertyChange("drivername", oldDrivername, drivername);
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        String oldCustomer = this.customer;
        this.customer = customer;
        changeSupport.firePropertyChange("customer", oldCustomer, customer);
    }

    public String getOrdertime() {
        return ordertime;
    }

    public void setOrdertime(String ordertime) {
        String oldOrdertime = this.ordertime;
        this.ordertime = ordertime;
        changeSupport.firePropertyChange("ordertime", oldOrdertime, ordertime);
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        String oldTime = this.time;
        this.time = time;
        changeSupport.firePropertyChange("time", oldTime, time);
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        String oldPrice = this.price;
        this.price = price;
        changeSupport.firePropertyChange("price", oldPrice, price);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Jobs)) {
            return false;
        }
        Jobs other = (Jobs) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hackneyproject.entities.Jobs[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
