/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hackneyproject.entities;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Dylan Sheridan
 */
@Entity
@Table(name = "DRIVERS")
@NamedQueries({
    @NamedQuery(name = "Drivers.findAll", query = "SELECT d FROM Drivers d"),
    @NamedQuery(name = "Drivers.findById", query = "SELECT d FROM Drivers d WHERE d.id = :id"),
    @NamedQuery(name = "Drivers.findByFirstname", query = "SELECT d FROM Drivers d WHERE d.firstname = :firstname"),
    @NamedQuery(name = "Drivers.findByAge", query = "SELECT d FROM Drivers d WHERE d.age = :age"),
    @NamedQuery(name = "Drivers.findByCartype", query = "SELECT d FROM Drivers d WHERE d.cartype = :cartype"),
    @NamedQuery(name = "Drivers.findByCarreg", query = "SELECT d FROM Drivers d WHERE d.carreg = :carreg")})
public class Drivers implements Serializable {
    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "FIRSTNAME")
    private String firstname;
    @Column(name = "AGE")
    private String age;
    @Column(name = "CARTYPE")
    private String cartype;
    @Column(name = "CARREG")
    private String carreg;

    public Drivers() {
    }

    public Drivers(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        String oldFirstname = this.firstname;
        this.firstname = firstname;
        changeSupport.firePropertyChange("firstname", oldFirstname, firstname);
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        String oldAge = this.age;
        this.age = age;
        changeSupport.firePropertyChange("age", oldAge, age);
    }

    public String getCartype() {
        return cartype;
    }

    public void setCartype(String cartype) {
        String oldCartype = this.cartype;
        this.cartype = cartype;
        changeSupport.firePropertyChange("cartype", oldCartype, cartype);
    }

    public String getCarreg() {
        return carreg;
    }

    public void setCarreg(String carreg) {
        String oldCarreg = this.carreg;
        this.carreg = carreg;
        changeSupport.firePropertyChange("carreg", oldCarreg, carreg);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Drivers)) {
            return false;
        }
        Drivers other = (Drivers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return firstname;
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
